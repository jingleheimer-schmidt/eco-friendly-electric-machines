#Overview
This mod makes all electric machines eco-friendly. If it runs on electricity, it won't produce pollution. 

Eco-Friendliness is adjustable in startup settings.

Certain machine categories (chemistry, mining, assembling, smelting) may be individually enabled/disabled.

---------------------
#Translation
Help translate Automatic Discharge Defense to more languages: https://crowdin.com/project/factorio-mods-localization
Currently available locale:
🇺🇸 English (en), 🇩🇪 German (de), 🇵🇱 Polish (pl), 🇷🇺 Russian (ru), 🇺🇦 Ukrainian (uk)

---------------------
#Compatibility
There are currently no known mod compatibility issues. To report a compatibility issue, please make a post on the discussion page. 

---------------------
#License
Eco-Friendly Electric Machines © 2024 by asher_sky is licensed under Attribution-NonCommercial-ShareAlike 4.0 International. 
To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/